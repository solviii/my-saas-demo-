# chmod +x ./init.sh
# ./init.sh
uvicorn  app.main:app --reload --use-colors

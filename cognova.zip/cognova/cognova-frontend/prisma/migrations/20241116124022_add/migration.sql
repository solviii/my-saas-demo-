-- AlterTable
ALTER TABLE "business_configs" ADD COLUMN     "estimatedDeliveryArrival" TEXT;

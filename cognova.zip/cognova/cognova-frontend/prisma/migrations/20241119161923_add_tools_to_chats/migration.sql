-- AlterTable
ALTER TABLE "chats" ADD COLUMN     "toolCallId" TEXT,
ADD COLUMN     "toolCalls" TEXT;

-- AlterTable
ALTER TABLE "conversations" ADD COLUMN     "extraMetadata" JSONB;

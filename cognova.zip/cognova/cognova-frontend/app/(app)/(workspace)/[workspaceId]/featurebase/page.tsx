import React from "react";

export default function Page() {
	return (
		<iframe
			className="flex-1 w-full h-[calc(100dvh-100px)]"
			src="https://{**}.featurebase.app/"
			frameBorder="0"
		/>
	);
}

import NotFound from "../not-found";

export default NotFound;

/** @type {import('next').NextConfig} */
const nextConfig = {
	swcMinify: true,
	images: {
		remotePatterns: [
			{
				protocol: "https",
				hostname: "**",
				port: "",
				pathname: "**",
			},
		],
		dangerouslyAllowSVG: true,
	},
	logging: {
		fetches: {
			fullUrl: true,
			hmrRefreshes: true,
		},
	},
	async redirects() {
		return [
			{
				source: "/affiliate",
				destination: "https://{**}.tolt.io",
				permanent: false,
			},
			{
				source: "/discord",
				destination: "https://discord.gg/{**}",
				permanent: false,
			},
		];
	},
};

module.exports = nextConfig;
